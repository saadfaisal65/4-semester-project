// DRClassification.js
import React, { useState } from "react";
import "./DRClassification.css";
import { Upload } from "lucide-react"; // If you have lucide-react installed

function DRClassification() {
  const [selectedFile, setSelectedFile] = useState(null);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  const handleDrop = (event) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handlePredict = () => {
    if (selectedFile) {
      alert(`Predicting for file: ${selectedFile.name}`);
      // Here you would typically send the file to a backend for prediction
    } else {
      alert("Please select a file first");
    }
  };

  return (
    <div className="dr-container">
      <div className="dr-card">
        <h1 className="dr-title">DR Classification with Transfer Learning</h1>

        <div
          className="upload-area"
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          onClick={() => document.getElementById("fileInput").click()}
        >
          <div className="upload-icon">
            {/* If you have lucide-react */}
            {typeof Upload !== "undefined" ? (
              <Upload size={48} />
            ) : (
              <svg
                width="48"
                height="48"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
              >
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="17 8 12 3 7 8" />
                <line x1="12" y1="3" x2="12" y2="15" />
              </svg>
            )}
          </div>
          <p className="upload-title">Drag and drop file here</p>
          <p className="upload-subtitle">
            Limit 200 MB per file - JPG, JPEG, PNG
          </p>
          <input
            type="file"
            id="fileInput"
            className="hidden-input"
            accept=".jpg,.jpeg,.png"
            onChange={handleFileChange}
          />

          <button className="browse-button">Browse files</button>
        </div>

        {selectedFile && (
          <p className="file-selected">Selected: {selectedFile.name}</p>
        )}

        <div className="predict-button-container">
          <button className="predict-button" onClick={handlePredict}>
            Predict
          </button>
        </div>
      </div>
    </div>
  );
}

export default DRClassification;
