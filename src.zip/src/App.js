import React from "react";
import "./App.css";
import DRClassification from "./components/DRClassification";

function App() {
  return (
    <div className="App">
      <DRClassification />
    </div>
  );
}

export default App;
